
public class arglist {
	String argname;
	arglist(String argument) {
		this.argname=argument;
	}
}
